from .allure_library import attach, attach_file

__all__ = ['attach', 'attach_file']
